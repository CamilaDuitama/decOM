# decOM package
decOM for contamination assessment using k-mer-based microbial sourcetracking
